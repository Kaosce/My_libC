/*
** my_isneg.c for my_isneg in /home/TiphaineLaurent/Library/V2/srcs/my
** 
** Made by Tiphaine LAURENT
** Login   <TiphaineLaurent@epitech.net>
** 
** Started on  Tue Apr 25 16:00:45 2017 Tiphaine LAURENT
** Last update Sun Apr 30 01:02:19 2017 Tiphaine LAURENT
*/

#include "my.h"

bool		my_isneg(const int nb)
{
  if (nb < 0)
    return (true);
  return (false);
}
