/*
** my_min.c for my_min in /home/TiphaineLaurent/Library/V2/libs_srcs/my
** 
** Made by Tiphaine LAURENT
** Login   <TiphaineLaurent@epitech.net>
** 
** Started on  Sun Apr 30 00:31:44 2017 Tiphaine LAURENT
** Last update Sun Apr 30 00:32:31 2017 Tiphaine LAURENT
*/

#include "my.h"

int		my_min(int a, int b)
{
  if (a < b)
    return (a);
  return (b);
}
