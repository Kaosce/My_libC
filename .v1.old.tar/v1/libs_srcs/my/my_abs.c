/*
** my_abs.c for my_abs in /home/TiphaineLaurent/Library/V2/libs_srcs/my
** 
** Made by Tiphaine LAURENT
** Login   <TiphaineLaurent@epitech.net>
** 
** Started on  Sun Apr 30 01:25:59 2017 Tiphaine LAURENT
** Last update Sun Apr 30 01:27:10 2017 Tiphaine LAURENT
*/

#include "my.h"

int		my_abs(int nb)
{
  if (nb < 0)
    return (-nb);
  return (nb);
}
