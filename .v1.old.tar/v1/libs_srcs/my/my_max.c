/*
** my_max.c for my_max in /home/TiphaineLaurent/Library/V2/libs_srcs/my
** 
** Made by Tiphaine LAURENT
** Login   <TiphaineLaurent@epitech.net>
** 
** Started on  Sun Apr 30 00:32:51 2017 Tiphaine LAURENT
** Last update Sun Apr 30 00:33:50 2017 Tiphaine LAURENT
*/

#include "my.h"

int		my_max(int a, int b)
{
  if (a > b)
    return (a);
  return (b);
}
